import java.awt.*;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

public class DrawingPanelView extends JPanel
{
	public DrawingPanelView()
	{
		setBackground(Color.white);
		setBounds(0,0,550,500);
		setBorder(BorderFactory.createTitledBorder("DRAW"));
	}
	
	public void paintComponent(Graphics g)
	{
		
	}
	
}
