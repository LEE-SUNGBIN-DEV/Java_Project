// �̱���
public class AppManager
{
	private static AppManager s_instance;
	private SimplePainterView _view;
	
	private AppManager()
	{
	}
	
	public SimplePainterView getView()
	{
		return _view;
	}
	
	public void setView(SimplePainterView view)
	{
		_view = view;
	}
	
	public static AppManager getInstance()
	{
		if (s_instance == null)
			s_instance = new AppManager();
		
		return s_instance;
	}

}
